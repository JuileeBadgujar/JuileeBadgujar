# python-aws-cdk-deploy-s3-bucket
How To Setup AWS S3 Bucket Using AWS CDK Python
