Guide to show you how to create an AWS S3 bucket using Python AWS CDK

Full tutorial can be found here:
https://unbiased-coder.com/setup-aws-s3-bucket-cdk-python/
